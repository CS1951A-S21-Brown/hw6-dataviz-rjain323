function changeURL(url){
    window.location = url;

}
console.log("hi")